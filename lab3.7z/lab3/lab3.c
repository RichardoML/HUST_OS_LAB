#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sem.h>
#define num 100//环形缓冲区个数
#define size 1024
union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short * arry;
};
int semid;//创建两个信号量 s0表示空闲缓冲区个数，s1表示缓冲区中的数据个数
char (*buf) [size];
int* inoutnum;
int* flag;
pid_t readproc,writeproc;
void P(int semid,int index);
void V(int semid,int index);
void* readtxt(void);
void* writetxt(void);
int main(void)
{
	int shm;
	shm = shmget(1,sizeof(char[size])*num,IPC_CREAT|0666);//选择1是为了进程能够共享，为不会再复制一份
	int shmindex;
	shmindex = shmget(2,sizeof(int)*4,IPC_CREAT|0666);//in out 指针和已经读入的个数 是否读完标志
	buf = shmat(shm,NULL,SHM_R|SHM_W);
	inoutnum = shmat(shmindex,NULL,SHM_R|SHM_W);
	
	inoutnum[0] = 0;
	inoutnum[1] = 0;
	inoutnum[2] = 0;
	inoutnum[3] = 0;
	
	semid = semget(3,2,IPC_CREAT|0666);
	
	union semun arg;
	arg.val = num;
	semctl(semid,0,SETVAL,arg);
	arg.val = 0;
	semctl(semid,1,SETVAL,arg);
	//创建信号量s0 = num s1 = 0
	readproc = fork();
	if(readproc == 0)
	{
		readtxt();
	}
	else
	{
		writeproc = fork();
		if(writeproc == 0)
		{
			writetxt();
		}
	}
	wait(readproc,NULL,0);
	wait(writeproc,NULL,0);
	
	semctl(semid,0,IPC_RMID);
	shmctl(shm,IPC_RMID,0);
	shmctl(shmindex,IPC_RMID,0);
	return 0;
}

void P(int semid,int index)
{
	struct sembuf sem;
	sem.sem_num = index;
	sem.sem_op = -1;
	sem.sem_flg = 0;
	semop(semid,&sem,1);
}

void V(int semid,int index)
{
	struct sembuf sem;
	sem.sem_num = index;
	sem.sem_op = 1;
	sem.sem_flg = 0;
	semop(semid,&sem,1);
}

void* readtxt(void)
{
	FILE* rtxt = fopen("input.txt","r");
	long readbytenum = 0;
	while(1)
	{
		P(semid,0);
		inoutnum[2] = fread(buf[inoutnum[0]],sizeof(char),size,rtxt);
		readbytenum += inoutnum[2];
		//printf("read %ld\n",readbytenum);
		V(semid,1);
		inoutnum[0] = (inoutnum[0]+1)%num;
		if(inoutnum[2]!= size) {inoutnum[3] = 1;break;} //说明读完了
	}
	return ;
}

void* writetxt(void)
{
	FILE* w = fopen("output.txt","w");
	long writebytenum = 0;
	while(1)
	{
		P(semid,1);
		if((inoutnum[1]+1)%num == inoutnum[0])//最后一个缓冲区
		{
						writebytenum += fwrite(buf[inoutnum[1]],sizeof(char),inoutnum[2],w);

			if(inoutnum[3] == 1)
			{
				break;
			}
		}
		else
		{
						writebytenum += fwrite(buf[inoutnum[1]],sizeof(char),size,w);

			inoutnum[1] = (inoutnum[1]+1) % num;
		}
		//printf("write %ld\n",writebytenum);
		V(semid,0);
	}
	return ;
}

