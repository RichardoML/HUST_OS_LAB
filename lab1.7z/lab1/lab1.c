#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
int pipefd[2];
pid_t proc1 ,proc2;
void parent(void);
void process1(void);
void process2(void);
int main(void)
{
	//pipiefd[0] for read and pipiefd[1] for write
	pipe(pipefd);
	
	signal(SIGINT,parent);

	proc1 = fork();
	if(proc1 == 0)//child proc 1
	{
		char buf[20];
		int time  = 1;//the send time
		signal(SIGINT,SIG_IGN);
		signal(SIGUSR1,process1);
		while(1)
		{
			sprintf(buf,"I send you %d time!\n",time);
			time++;
			write(pipefd[1],buf,sizeof(buf));
			sleep(1);
		}
		
	}
	else
	{
		proc2 = fork();
		if(proc2 == 0)//child proc 2
		{
			char store[20];
			signal(SIGINT,SIG_IGN);
			signal(SIGUSR1,process2);
			while(1)
			{
				read(pipefd[0],store,sizeof(store));
				printf("%s",store);
			}
		}
			
	}
	wait(proc1,NULL,0);
	wait(proc2,NULL,0);
	close(pipefd[0]);
	close(pipefd[1]);
	printf("Parent Proccess Is Killed!\n");

	return 0;
}

void parent(void)
{
	//receive SIGINT signal and send KILL signal to child process
	kill(proc1,SIGUSR1);
	kill(proc2,SIGUSR1);
	
}

void process1(void)
{
	close(pipefd[0]);
	close(pipefd[1]);
	printf("Child Process 1 is killed!\n");
	exit(0);
}

void process2(void)
{
	close(pipefd[0]);
	close(pipefd[1]);
	printf("Child Process 2 is killed!\n");
	exit(0);
}
