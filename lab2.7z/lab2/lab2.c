#include <linux/sem.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
int semid;
int a;
pthread_t p1,p2;
void P(int semid,int index);
void V(int semid,int index);
void* subp1(void);
void* subp2(void);
int main(void)
{

	semid = semget(0,2,IPC_CREAT|0666);//key=0:建立新信号量集对象 nsems =2 
	/*
		相当于创建了两个信号量s0:表示缓冲区为空 s1：表示缓冲区中的数据
	*/

	//init 
	union semun arg;
	arg.val = 1;
	semctl(semid,0,SETVAL,arg);
	arg.val = 0;
	semctl(semid,1,SETVAL,arg);
	//s0 = 1.s1 =0 表示初始状态 缓冲区空 无数据
	
	//创建两个线程
	a=0;
	pthread_create(&p1,NULL,subp1,NULL);
	pthread_create(&p2,NULL,subp2,NULL);

	//等待线程运行结束
	pthread_join(p1,NULL);
	pthread_join(p2,NULL);
	
	//删除信号灯
	semctl(semid,0,IPC_RMID);
	return 0;
}

void P(int semid,int index)
{
	struct sembuf sem;
	sem.sem_num = index;
	sem.sem_op = -1;
	sem.sem_flg = 0;
	semop(semid,&sem,1);//1表示命令执行个数为1
}

void V(int semi,int index)
{
	struct sembuf sem;
	sem.sem_num = index;
	sem.sem_op = 1;
	sem.sem_flg = 0;
	semop(semid,&sem,1);
	
}

void* subp1(void)//从公共缓冲区读数据显示
{
	int i;
	for(i=0;i<100;i++)
	{
		P(semid,1);
		printf("%d\t",a);
		V(semid,0);
	}
	return NULL;
}

void* subp2(void)//往缓冲区写结果
{
	int i;
	for(i=0;i<100;i++)
	{
		P(semid,0);
		a = a+i+1;
		V(semid,1);	
	}
}
