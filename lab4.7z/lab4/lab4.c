#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
void printdir(char* dir,int depth);
void printauthority(mode_t mode);
void printinfo(struct stat state);
int main(int argc,char* argv[])//第二个参数指定路径
{
	if(argc == 1) 
	{
		printf("lack of path!\n");
	}
	else
	printdir(argv[1],0);
	return 0;
}

void printdir(char* dir,int depth)
{
	DIR* dp;
	//char* pdir;//present directory
	struct dirent* entry;
	struct stat* statbuf;
	statbuf = (struct stat*)malloc(sizeof(struct stat));
	if((dp=opendir(dir)) == NULL)//打开目录失败
	{
		printf("Fail to open the directory:%s\n",dir);
		return;	
	}
	chdir(dir);//进入当前的目录
	while((entry = readdir(dp))!= NULL)//读取一个目录项
	{
		
		lstat(entry->d_name,statbuf);//用目录项的名字来读取目录项的信息
		if( S_ISDIR(statbuf->st_mode) )//目录项是一个目录
		{
			if((!strcmp(entry->d_name,".."))||(!strcmp(entry->d_name,".")))//遇到.和 .. 跳过
			{
				continue;
			}
			else//下一级的目录
			{
				printf("depth:%-3d ",depth);
			  	printauthority(statbuf->st_mode);
			  	printinfo(*statbuf);
			  	printf("%s\n",entry->d_name);
			  	printdir(entry->d_name,depth+4);
			}
		}
		else//不是目录，而是一个普通文件
		{
			printf("depth:%-3d ",depth);
			printauthority(statbuf->st_mode);
			printinfo(*statbuf);
			printf("%s\n",entry->d_name);
		}
	}
	chdir("../");
	closedir(dp);
}

void printauthority(mode_t mode)
{
	if(S_ISLNK(mode)) putchar('l');
	if(S_ISDIR(mode)) putchar('d');
	if(S_ISREG(mode)) putchar('-');
	if(S_ISCHR(mode)) putchar('c');
	if(S_ISBLK(mode)) putchar('b');
	if(S_ISFIFO(mode)) putchar('f');
	if(S_ISSOCK(mode)) putchar('s');
	if(S_IRUSR&mode) putchar('r'); else putchar('-');
	if(S_IWUSR&mode) putchar('w'); else putchar('-');
	if(S_IXUSR&mode) putchar('x'); else putchar('-');
	if(S_IRGRP&mode) putchar('r'); else putchar('-');
	if(S_IWGRP&mode) putchar('w'); else putchar('-');
	if(S_IXGRP&mode) putchar('x'); else putchar('-');
	if(S_IROTH&mode) putchar('r'); else putchar('-');
	if(S_IWOTH&mode) putchar('w'); else putchar('-');
	if(S_IXOTH&mode) putchar('x'); else putchar('-');
	 putchar(' ');
	
	 
}

void printinfo(struct stat state)
{
	printf("%-2d",state.st_nlink);
	
	struct passwd* pwd;
	pwd = getpwuid(state.st_uid);
	printf("%-15s",pwd->pw_name);
	
	struct group* grp;
	grp = getgrgid(state.st_gid);
	printf("%-15s",grp->gr_name);
	
	printf("%-10ld",state.st_size);

	time_t t = state.st_mtime;
	struct tm time;
	localtime_r(&t,&time);
	printf("%-5d年",time.tm_year+1900);
	printf("%-2d月",time.tm_mon+1);
	printf("%-2d日 ",time.tm_mday);
	
}
